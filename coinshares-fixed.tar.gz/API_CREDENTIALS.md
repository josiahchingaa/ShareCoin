# API Credentials & Configuration

## 📋 Summary of All APIs

| API | Purpose | Cost | Rate Limit | Status |
|-----|---------|------|------------|--------|
| **Alpha Vantage** | Stock/Crypto prices | FREE | 25/day | ✅ Configured |
| **NewsAPI** | Market news | FREE | 100/day | ✅ Configured |
| **CoinGecko** | Crypto prices | FREE | 50/min | ✅ Configured |
| **Yahoo Finance** | Stock prices | FREE | Unlimited | ✅ Ready (no key needed) |
| **Groq AI** | AI Analytics | FREE | 14,400/day | ✅ Configured |

**Total Cost: $0/month** 🎉

---

## Alpha Vantage API
**Documentation:** https://www.alphavantage.co/documentation/

### Primary Account
- **API Key:** `R2CSCPKV89MFG1FA`
- **Email:** pawelpiotrkowskii@gmail.com
- **Tier:** Free (25 calls/day)
- **Rate Limit:** 5 API calls per minute, 25 calls per day

### Usage:
```
Stock Quote: https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=AAPL&apikey=R2CSCPKV89MFG1FA
Crypto Quote: https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=BTC&to_currency=USD&apikey=R2CSCPKV89MFG1FA
News & Sentiment: https://www.alphavantage.co/query?function=NEWS_SENTIMENT&apikey=R2CSCPKV89MFG1FA
```

---

---

## NewsAPI.org (Market News)
**Documentation:** https://newsapi.org/docs

### Account Details
- **API Key:** `145ff30532674281be9251ab9f76f1b4`
- **Free Tier:** 100 requests/day
- **Coverage:** 80,000+ news sources worldwide

### Usage:
```
API Endpoint: https://newsapi.org/v2/top-headlines
Parameters: category=business&apiKey={API_KEY}
```

---

## CoinGecko API (Crypto Prices)
**Documentation:** https://www.coingecko.com/en/api

### Account Details
- **API Key:** `CG-1WQq6y3Pw2o3RoD14JhwG97t`
- **Free Tier:** 10-50 calls/minute
- **Coverage:** 10,000+ cryptocurrencies

### Usage:
```
API Endpoint: https://api.coingecko.com/api/v3/simple/price
Parameters: ids=bitcoin&vs_currencies=usd&x_cg_demo_api_key={API_KEY}
```

---

## Yahoo Finance (Stock Prices)
**Documentation:** Public API (no key required)

### Account Details
- **API Key:** Not required (100% FREE, no limits!)
- **Library:** Use `yahoo-finance2` npm package
- **Coverage:** All global stocks, ETFs, indices

### Usage:
```javascript
import yahooFinance from 'yahoo-finance2';

// Get stock quote
const quote = await yahooFinance.quote('AAPL');

// Get historical data
const history = await yahooFinance.historical('AAPL', {
  period1: '2023-01-01',
  period2: '2024-01-01'
});
```

**Why Yahoo Finance is Perfect:**
- ✅ No API key needed
- ✅ No rate limits
- ✅ Real-time prices
- ✅ Historical data
- ✅ Completely free forever

---

## Groq API (AI Analytics)
**Documentation:** https://console.groq.com/docs

### Account Details
- **API Key:** `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`
- **Model Used:** Llama 3.3 70B Versatile
- **Free Tier:** 14,400 requests/day
- **Speed:** Ultra-fast inference (faster than OpenAI)

### Usage:
```
API Endpoint: https://api.groq.com/openai/v1/chat/completions
Headers: Authorization: Bearer {API_KEY}
Model: llama-3.3-70b-versatile
```

---

## Environment Variables

Add to `.env`:
```
# Financial APIs
ALPHA_VANTAGE_API_KEY=K0PTUETP69L72QYU
NEWS_API_KEY=145ff30532674281be9251ab9f76f1b4
COINGECKO_API_KEY=CG-1WQq6y3Pw2o3RoD14JhwG97t

# AI APIs
GROQ_API_KEY=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
```

---

## API Endpoints We'll Use

### 1. Real-time Stock Prices
```
GET /query?function=GLOBAL_QUOTE&symbol={SYMBOL}&apikey={API_KEY}
```

### 2. Crypto Prices
```
GET /query?function=CURRENCY_EXCHANGE_RATE&from_currency=BTC&to_currency=USD&apikey={API_KEY}
```

### 3. Market News
```
GET /query?function=NEWS_SENTIMENT&tickers={SYMBOLS}&apikey={API_KEY}
```

### 4. Historical Data (for charts)
```
GET /query?function=TIME_SERIES_DAILY&symbol={SYMBOL}&apikey={API_KEY}
```

---

## Rate Limiting Strategy

**Free Tier Limits:**
- 5 calls per minute
- 25 calls per day

**Caching Strategy:**
- Cache stock prices for 5 minutes
- Cache crypto prices for 2 minutes
- Cache news for 30 minutes
- Use database to store historical data

**Implementation:**
- Backend API routes with caching
- Batch requests when possible
- Update prices on-demand, not automatically

---

## Alternative APIs (For Future)

### Financial Modeling Prep (FMP)
- Free tier: 250 calls/day
- Better for scaling
- More comprehensive data

### CoinGecko (Crypto only)
- Free tier: 10-50 calls/minute
- Good for crypto prices
- No API key required

---

## Notes
- Keep API keys in `.env.local` (never commit to git)
- Monitor daily usage to stay within limits
- Consider upgrading if we exceed 25 calls/day
- Alpha Vantage Premium: $50/month for unlimited calls
