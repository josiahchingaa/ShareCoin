import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user?.role !== "CUSTOMER") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const userId = session.user.id;

    // Get user's trades from database
    const trades = await prisma.trade.findMany({
      where: { userId },
      orderBy: { executedAt: "desc" },
    });

    // If no trades yet, return mock data
    if (trades.length === 0) {
      const mockTrades = [
        {
          id: "trade_001",
          type: "BUY",
          asset: "Bitcoin",
          quantity: 0.5,
          pricePerUnit: 42000,
          totalAmount: 21000,
          fees: 42,
          profitLoss: 3115,
          status: "COMPLETED",
          executedAt: new Date("2024-01-16T09:30:00").toISOString(),
        },
        {
          id: "trade_002",
          type: "BUY",
          asset: "Ethereum",
          quantity: 10,
          pricePerUnit: 2250,
          totalAmount: 22500,
          fees: 45,
          profitLoss: 905,
          status: "COMPLETED",
          executedAt: new Date("2024-01-16T11:15:00").toISOString(),
        },
        {
          id: "trade_003",
          type: "BUY",
          asset: "Bitcoin",
          quantity: 1.0432,
          pricePerUnit: 43500,
          totalAmount: 45379.2,
          fees: 90.76,
          profitLoss: 1805.98,
          status: "COMPLETED",
          executedAt: new Date("2024-01-20T14:20:00").toISOString(),
        },
        {
          id: "trade_004",
          type: "BUY",
          asset: "Cardano",
          quantity: 15000,
          pricePerUnit: 0.48,
          totalAmount: 7200,
          fees: 14.4,
          profitLoss: 600,
          status: "COMPLETED",
          executedAt: new Date("2024-01-23T10:45:00").toISOString(),
        },
        {
          id: "trade_005",
          type: "BUY",
          asset: "Ethereum",
          quantity: 8.234,
          pricePerUnit: 2420,
          totalAmount: 19926.28,
          fees: 39.85,
          profitLoss: -780.97,
          status: "COMPLETED",
          executedAt: new Date("2024-02-02T15:30:00").toISOString(),
        },
        {
          id: "trade_006",
          type: "BUY",
          asset: "Solana",
          quantity: 45.67,
          pricePerUnit: 95.20,
          totalAmount: 4347.78,
          fees: 8.7,
          profitLoss: 150.57,
          status: "COMPLETED",
          executedAt: new Date("2024-02-08T11:00:00").toISOString(),
        },
        {
          id: "trade_007",
          type: "BUY",
          asset: "Polkadot",
          quantity: 120.5,
          pricePerUnit: 5.50,
          totalAmount: 662.75,
          fees: 1.33,
          profitLoss: 12.05,
          status: "COMPLETED",
          executedAt: new Date("2024-02-12T16:20:00").toISOString(),
        },
        {
          id: "trade_008",
          type: "SELL",
          asset: "Cardano",
          quantity: 5000,
          pricePerUnit: 0.54,
          totalAmount: 2700,
          fees: 5.4,
          profitLoss: 300,
          status: "COMPLETED",
          executedAt: new Date("2024-02-15T09:45:00").toISOString(),
        },
      ];

      return NextResponse.json({ trades: mockTrades });
    }

    return NextResponse.json({ trades });
  } catch (error) {
    console.error("Error fetching trades:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
