import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user?.role !== "CUSTOMER") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const userId = session.user.id;

    // Get user's portfolio
    const portfolio = await prisma.portfolio.findUnique({
      where: { userId },
      include: {
        holdings: true,
      },
    });

    if (!portfolio) {
      return NextResponse.json({ error: "Portfolio not found" }, { status: 404 });
    }

    // For now, return mock data with some holdings
    // TODO: Integrate with real market data APIs
    const mockData = {
      totalValue: 125450.32,
      totalInvested: 100000,
      profitLoss: 25450.32,
      profitLossPercentage: 25.45,
      dailyChange: 1205.45,
      dailyChangePercentage: 0.97,
      holdings: [
        {
          asset: "Bitcoin",
          quantity: 1.5432,
          currentPrice: 45230.00,
          value: 69800.42,
          change24h: 2.34,
          allocation: 55.6,
        },
        {
          asset: "Ethereum",
          quantity: 18.234,
          currentPrice: 2340.50,
          value: 42680.31,
          change24h: -0.87,
          allocation: 34.0,
        },
        {
          asset: "Cardano",
          quantity: 15000,
          currentPrice: 0.52,
          value: 7800.00,
          change24h: 5.23,
          allocation: 6.2,
        },
        {
          asset: "Solana",
          quantity: 45.67,
          currentPrice: 98.50,
          value: 4498.90,
          change24h: 1.45,
          allocation: 3.6,
        },
        {
          asset: "Polkadot",
          quantity: 120.5,
          currentPrice: 5.60,
          value: 674.80,
          change24h: -2.11,
          allocation: 0.5,
        },
      ],
      performance: [
        { date: "Day 1", value: 98500 },
        { date: "Day 5", value: 101200 },
        { date: "Day 10", value: 99800 },
        { date: "Day 15", value: 105400 },
        { date: "Day 20", value: 108900 },
        { date: "Day 25", value: 112300 },
        { date: "Day 30", value: 125450 },
      ],
    };

    return NextResponse.json(mockData);
  } catch (error) {
    console.error("Error fetching portfolio:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
