import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // PRIMARY BLUE COLORS (New Design System)
        primary: {
          DEFAULT: "#0052FF",
          hover: "#0046DD",
          active: "#003DB8",
          electric: "#60A5FA",
          deep: "#1E3A8A",
        },
        // SEMANTIC COLORS
        success: {
          DEFAULT: "#10B981",
          bg: "rgba(16, 185, 129, 0.15)",
        },
        danger: {
          DEFAULT: "#EF4444",
          bg: "rgba(239, 68, 68, 0.15)",
        },
        warning: {
          DEFAULT: "#F59E0B",
          bg: "rgba(245, 158, 11, 0.15)",
        },
        info: {
          DEFAULT: "#3B82F6",
          bg: "rgba(59, 130, 246, 0.15)",
        },
        // BACKGROUND COLORS
        background: {
          main: "#0A0A0A",
          card: "#141414",
          elevated: "#1A1A1A",
          hover: "#1E1E1E",
          // Legacy support
          primary: "#1a1a1a",
          secondary: "#2a2a2a",
          tertiary: "#0a0e27",
        },
        // TEXT COLORS
        text: {
          primary: "#FFFFFF",
          secondary: "#A3A3A3",
          tertiary: "#737373",
          disabled: "#525252",
        },
        // BORDER COLORS
        border: {
          DEFAULT: "#262626",
          hover: "#404040",
        },
        // LEGACY ACCENT COLORS (Keep for compatibility)
        accent: {
          green: "#10B981",
          greenAlt: "#22c55e",
          red: "#EF4444",
          redAlt: "#ff6b6b",
          gold: "#d4af37",
          goldAlt: "#f59e0b",
          blue: "#3B82F6",
        },
      },
      fontFamily: {
        sans: ["Inter", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "sans-serif"],
      },
      fontSize: {
        xs: ["12px", { lineHeight: "1.5" }],
        sm: ["14px", { lineHeight: "1.5" }],
        base: ["16px", { lineHeight: "1.5" }],
        lg: ["18px", { lineHeight: "1.5" }],
        xl: ["20px", { lineHeight: "1.2" }],
        "2xl": ["24px", { lineHeight: "1.2" }],
        "3xl": ["28px", { lineHeight: "1.2" }],
        "4xl": ["32px", { lineHeight: "1.2" }],
        "5xl": ["36px", { lineHeight: "1.2" }],
      },
      spacing: {
        xs: "4px",
        sm: "8px",
        md: "16px",
        lg: "24px",
        xl: "32px",
        "2xl": "48px",
        "3xl": "64px",
      },
      borderRadius: {
        sm: "6px",
        md: "8px",
        lg: "12px",
        xl: "16px",
        full: "9999px",
      },
      boxShadow: {
        sm: "0 1px 3px rgba(0, 0, 0, 0.3)",
        DEFAULT: "0 4px 6px rgba(0, 0, 0, 0.4)",
        md: "0 4px 6px rgba(0, 0, 0, 0.4)",
        lg: "0 10px 15px rgba(0, 0, 0, 0.5)",
        xl: "0 20px 25px rgba(0, 0, 0, 0.6)",
        "glow-blue": "0 0 20px rgba(0, 82, 255, 0.3)",
        "glow-blue-subtle": "0 0 20px rgba(0, 82, 255, 0.15)",
        "glow-blue-intense": "0 0 30px rgba(0, 82, 255, 0.5)",
      },
      transitionDuration: {
        fast: "150ms",
        DEFAULT: "200ms",
        slow: "300ms",
      },
      backgroundImage: {
        "gradient-blue": "linear-gradient(135deg, #0052FF 0%, #60A5FA 100%)",
        "gradient-blue-vertical": "linear-gradient(180deg, #0052FF 0%, #60A5FA 100%)",
        "gradient-blue-horizontal": "linear-gradient(90deg, rgba(0, 82, 255, 0.15) 0%, transparent 100%)",
      },
    },
  },
  plugins: [],
}

export default config
