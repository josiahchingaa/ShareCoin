import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user?.role !== "CUSTOMER") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const userId = session.user.id;

    // Get user's transactions from database
    const transactions = await prisma.transaction.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });

    // If no transactions yet, return mock data
    if (transactions.length === 0) {
      const mockTransactions = [
        {
          id: "tx_001",
          type: "DEPOSIT",
          amount: 50000,
          status: "COMPLETED",
          createdAt: new Date("2024-01-15T10:30:00").toISOString(),
          processedAt: new Date("2024-01-15T10:35:00").toISOString(),
          notes: "Initial deposit - Bank transfer",
        },
        {
          id: "tx_002",
          type: "DEPOSIT",
          amount: 30000,
          status: "COMPLETED",
          createdAt: new Date("2024-01-22T14:20:00").toISOString(),
          processedAt: new Date("2024-01-22T14:25:00").toISOString(),
          notes: "Additional deposit",
        },
        {
          id: "tx_003",
          type: "DEPOSIT",
          amount: 20000,
          status: "COMPLETED",
          createdAt: new Date("2024-02-05T09:15:00").toISOString(),
          processedAt: new Date("2024-02-05T09:20:00").toISOString(),
          notes: "Bank wire transfer",
        },
        {
          id: "tx_004",
          type: "WITHDRAWAL",
          amount: 5000,
          status: "COMPLETED",
          createdAt: new Date("2024-02-10T16:45:00").toISOString(),
          processedAt: new Date("2024-02-10T17:00:00").toISOString(),
          notes: "Profit withdrawal",
        },
        {
          id: "tx_005",
          type: "DEPOSIT",
          amount: 15000,
          status: "PENDING",
          createdAt: new Date("2024-02-18T11:00:00").toISOString(),
          processedAt: null,
          notes: "Pending verification",
        },
      ];

      return NextResponse.json({ transactions: mockTransactions });
    }

    return NextResponse.json({ transactions });
  } catch (error) {
    console.error("Error fetching transactions:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
